﻿using Dapper;
using DBEntity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace DBContext
{
    public class ProjectRepository : BaseRepository, IProjectRepository
    {
        public ResponseBase getProject(int id)
        {
            throw new NotImplementedException();
        }

        public ResponseBase getProjects()
        {
            var returnEntity = new ResponseBase();
            var entitiesProjects = new List<EntityProject>();
            var imageRepository = new ImageRepository();

            try
            {
                using (var db = GetSqlConnection())
                {
                    const string sql = @"usp_ListarProyectos";
                    entitiesProjects = db.Query<EntityProject>(sql: sql, commandType: CommandType.StoredProcedure).ToList();

                    foreach(var obj in entitiesProjects)
                    {
                        obj.images = imageRepository.getImages(obj.idProyecto);
                    }

                    if(entitiesProjects.Count > 0)
                    {
                        returnEntity.isSuccess = true;
                        returnEntity.errorCode = "0000";
                        returnEntity.errorMessage = string.Empty;
                        returnEntity.data = entitiesProjects;
                    }
                    else
                    {
                        returnEntity.isSuccess = false;
                        returnEntity.errorCode = "0000";
                        returnEntity.errorMessage = string.Empty;
                        returnEntity.data = null;
                    }
                }
            }
            catch(Exception ex)
            {
                returnEntity.isSuccess = false;
                returnEntity.errorCode = "0001";
                returnEntity.errorMessage = ex.Message;
                returnEntity.data = null;
            }

            return returnEntity;
        }
    }
}
