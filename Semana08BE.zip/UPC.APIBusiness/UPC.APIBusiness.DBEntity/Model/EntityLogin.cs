﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DBEntity
{
    public class EntityLogin
    {
        public string LoginUsuario { get; set; }
        public string PasswordUsuario { get; set; }
    }
}
